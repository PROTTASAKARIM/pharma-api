const multiplePriceSave = () => {

    const priceList = req.body;

}
module.exports = {
    multiplePriceSave
}